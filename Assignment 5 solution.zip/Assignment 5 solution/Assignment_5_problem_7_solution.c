//Write a program to print the first N even natural numbers in reverse order.
#include <stdio.h>
int main ()
{
    int num,i;
    printf("Enter any number: ");
    scanf("%d",&num);
    for(i=num;i>=1;i--)
    {
        printf("%d\n",i*2);
    }
    return 0;
}
