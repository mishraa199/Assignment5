//Write a program to print the first N odd natural numbers in reverse order.
#include <stdio.h>
int main ()
{
    int num,i;
    printf("Enter any number: ");
    scanf("%d",&num);
    for(i=num;i>=1;i--)
    {
        printf("%d\n",2*i-1);
    }
    return 0;
}
