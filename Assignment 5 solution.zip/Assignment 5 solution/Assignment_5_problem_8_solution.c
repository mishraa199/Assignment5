//Write a program to print squares of the first N natural numbers.
#include <stdio.h>
int main ()
{
    int num,i;
    printf("Enter any number: ");
    scanf("%d",&num);
    for(i=1;i<=num;i++)
    {
        printf("%d\n",i*i);
    }
    return 0;
}
