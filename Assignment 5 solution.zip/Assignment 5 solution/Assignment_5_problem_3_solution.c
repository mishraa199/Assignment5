//Write a program to print the first N natural numbers.
#include <stdio.h>
int main ()
{
    int num,i;
    printf("Enter any number: ");
    scanf("%d",&num);
    for(i=num;i>=1;i--)
    {
        printf("%d\n",i);
    }
    return 0;
}
